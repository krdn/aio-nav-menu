export { AppServerModule } from './app/app.server.module';
