import { Component } from '@angular/core';

@Component({
  selector: 'toh-app',
  template: `
      Tour of Heroes
    `
})
export class AppComponent { }
