import { Component, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'toh-hero',
  template: `...`
})
export class HeroComponent {
  @Output() savedTheDay = new EventEmitter<boolean>();
}


