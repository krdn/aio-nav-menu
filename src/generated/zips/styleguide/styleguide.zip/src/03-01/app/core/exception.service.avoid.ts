import { Injectable } from '@angular/core';

@Injectable()
/* avoid */

export class exceptionService {
  constructor() { }
}
