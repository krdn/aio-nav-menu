import { Component } from '@angular/core';

@Component({
  template: '<div>hero component</div>',
  selector: 'toh-hero'
})
export class HeroComponent {}
