export * from './hero.component';
